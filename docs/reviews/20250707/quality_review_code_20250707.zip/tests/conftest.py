# tests/conftest.py

# Geen expliciete plugins laden, Syrupy regelt dit zelf.
# Alleen fixtures of test-hulpmiddelen definieer je hier indien nodig.