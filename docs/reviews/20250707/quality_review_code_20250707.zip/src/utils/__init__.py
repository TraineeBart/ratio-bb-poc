# ╭──────────────────────────────────────────────────────────────╮
# │ File: src/utils/__init__.py                                 │
# │ Module: utils                                               │
# │ Doel: Init file om van deze map een Python package te maken│
# │ Auteur: DeveloperGPT                                        │
# │ Laatste wijziging: 2025-07-04                               │
# │ Status: stable                                              │
# ╰──────────────────────────────────────────────────────────────╯