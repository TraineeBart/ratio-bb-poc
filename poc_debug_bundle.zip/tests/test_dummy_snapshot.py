def test_dummy_snapshot(snapshot):
    value = {"key": "value"}
    assert value == snapshot