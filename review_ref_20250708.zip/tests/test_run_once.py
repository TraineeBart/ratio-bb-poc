import os
import sys
import json
import csv
import pytest
import requests

# Make sure src is importable
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from src.run_once import main

@pytest.fixture(autouse=True)
def isolate_fs(monkeypatch, tmp_path):
    # switch working directory to tmp_path
    monkeypatch.chdir(tmp_path)
    # patch load_config to minimal config
    fake_cfg = {
        'symbols': ['AAA'],
        'historical_csv_path': 'tmp/historical.csv',
        'webhook_url': 'https://example.com/hook'
    }
    monkeypatch.setattr('src.run_once.load_config', lambda: fake_cfg)
    yield

def write_json_ticks(path, ticks):
    with open(path, 'w') as f:
        json.dump(ticks, f)

def read_csv(path):
    with open(path, newline='') as f:
        return list(csv.DictReader(f))

def test_replay_success(monkeypatch, tmp_path, capsys):
    # Prepare JSON file
    ticks = [
        {'symbol': 'AAA', 'price': 1.0, 'timestamp': 1620000000},
        {'symbol': 'AAA', 'price': 2.0, 'timestamp': 1620000060}
    ]
    json_path = tmp_path / 'ticks.json'
    write_json_ticks(str(json_path), ticks)
    # Patch requests.post to capture calls
    posts = []
    def fake_post(url, json=None, timeout=None):
        posts.append((url, json))
        class R: 
            def raise_for_status(self): pass
        return R()
    monkeypatch.setattr(requests, 'post', fake_post)

    # Run in replay mode by setting argv
    monkeypatch.setenv('PYTEST_RUNNING', '1')  # ensure monkeypatch fixture is used
    sys.argv = ['run_once', '--replay', str(json_path)]
    main()
    # Check CSV output
    rows = read_csv('tmp/output.csv')
    assert len(rows) == 1  # single signal at end
    # Check POST called once
    # Expect default WEBHOOK_URL from config fixture
    assert posts and posts[0][0] == 'http://localhost:5001/webhook'
    # Check stdout printed JSON of signal
    captured = capsys.readouterr()
    # Extract JSON output line (ignore debug prints)
    lines = [l for l in captured.out.splitlines() if l.strip().startswith('{')]
    assert lines, "No JSON output found in stdout"
    output = json.loads(lines[-1])
    assert isinstance(output, dict)
    assert output['signal'] in ['BUY','SELL','HOLD']

def test_replay_file_not_found():
    sys.argv = ['run_once', '--replay', 'nonexistent.json']
    with pytest.raises(FileNotFoundError):
        main()

def test_live_success(monkeypatch, tmp_path, capsys):
    # Prepare historical CSV
    hist_path = tmp_path / 'historical.csv'
    with open(hist_path, 'w', newline='') as f:
        writer = csv.writer(f)
        writer.writerow(['price','nk','volume'])
        writer.writerow([1.0,1,100])
        writer.writerow([2.0,1,100])
        writer.writerow([3.0,1,100])
    # Configure config to point to our CSV
    monkeypatch.setenv('HISTORICAL_CSV_PATH', str(hist_path))
    cfg = {
        'symbols': ['AAA'],
        'historical_csv_path': str(hist_path),
        'webhook_url': 'https://example.com/hook'
    }
    monkeypatch.setattr('src.run_once.load_config', lambda: cfg)
    # Mock the health server bind to avoid port-in-use errors
    monkeypatch.setattr('src.run_once.start_health_server', lambda port=8000: None)
    # Mock WSClient to simulate one tick then exit
    class DummyClient:
        def __init__(self, symbols, on_tick):
            self.symbols = symbols
            self._on_tick = on_tick
        def start(self):
            # simulate one tick event
            tick = {
                'symbol': self.symbols[0],
                'price': 1.23,
                'timestamp': '2025-07-08T00:00:00+00:00',
                'signal': 'HOLD'
            }
            self._on_tick(tick)
        def stop(self):
            pass
    monkeypatch.setattr('src.ws_client.WSClient', DummyClient)
    # Stub time.sleep: raise KeyboardInterrupt only in the main thread, no-op in background threads
    import src.run_once as _run_once_mod
    import threading as _threading
    def fake_sleep(sec):
        if _threading.current_thread().name == 'MainThread':
            raise KeyboardInterrupt()
        return None
    monkeypatch.setattr(_run_once_mod.time, 'sleep', fake_sleep)
    # Stub threading.Thread to prevent any background threads from starting
    import threading as _threading
    class DummyThread:
        def __init__(self, *args, **kwargs):
            pass
        def start(self):
            pass
    monkeypatch.setattr(_threading, 'Thread', DummyThread)
    # Patch requests.post
    # Patch requests.post
    posts = []
    monkeypatch.setattr(requests, 'post', lambda url, json=None, timeout=None: type('R', (), {'raise_for_status': lambda s: None})())
    # Run live mode
    sys.argv = ['run_once']
    main()
    # Validate CSV and stdout
    rows = read_csv('tmp/output.csv')
    assert len(rows) == 1
    out = capsys.readouterr().out
    assert '"signal"' in out

def test_live_file_not_found(monkeypatch):
    # Ensure live-mode override is disabled to test historical branch
    monkeypatch.delenv('MODE', raising=False)
    # Config points to missing file
    cfg = {'historical_csv_path': 'missing.csv'}
    monkeypatch.setattr('src.run_once.load_config', lambda: cfg)
    sys.argv = ['run_once']
    with pytest.raises(FileNotFoundError):
        main()
